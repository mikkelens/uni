import java.io.IOException;
import java.net.URISyntaxException;

public class Test {
    public static void main(String[] args) throws IOException, URISyntaxException {
        TestServer.testAndOpenInBrowser("animal");
    }
}